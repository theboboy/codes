package com.theboboy.ext4.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.theboboy.ext4.entity.Menu;
import com.theboboy.ext4.po.Tree;
import com.theboboy.ext4.po.TreeNode;

@Controller
@RequestMapping("menu")
public class MenuController {

	@RequestMapping("tree")
	@ResponseBody
	public List<TreeNode> tree() {
		
		Menu m1 = new Menu("1", "菜单1", 1, "01", null, null, null);
		Menu m2 = new Menu("2", "菜单2", 2, "02", null, null, null);
		
		Menu m11 = new Menu("11", "菜单11", 257, "0101", "1", null, null);
		Menu m12 = new Menu("12", "菜单12", 258, "0102", "1", null, "Menu12");
		Menu m13 = new Menu("13", "菜单13", 259, "0103", "1", null, "Menu13");
		
		Menu m21 = new Menu("21", "菜单21", 513, "0201", "2", null, "Menu21");
		Menu m22 = new Menu("22", "菜单22", 514, "0202", "2", null, "Menu22");
		Menu m23 = new Menu("23", "菜单23", 515, "0203", "2", null, "Menu23");
		
		Menu m111 = new Menu("111", "菜单111", 65793, "010101", "11", null, "Menu111");
		Menu m112 = new Menu("112", "菜单112", 65794, "010102", "11", null, "Menu112");
		Menu m113 = new Menu("113", "菜单113", 65795, "010103", "11", null, "Menu113");
		
		ArrayList<Menu> menus = new ArrayList<Menu>();
		
		menus.add(m111);
		menus.add(m112);
		menus.add(m113);
		
		menus.add(m11);
		menus.add(m12);
		menus.add(m13);
		
		menus.add(m1);
		menus.add(m2);
		
		menus.add(m21);
		menus.add(m22);
		menus.add(m23);
		
		Tree tree = new Tree().constructByMenus(menus);
		
		return tree.getRoot().getChildren();
		
	}

}
