package com.theboboy.ext4.util;

import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.id.IdentifierGenerator;

/**
 * @Id
 * @GenericGenerator(name = "uuidGenerator", strategy = "com.theboboy.util.utils.Base64UuidGenerator")
 * @GeneratedValue(generator = "uuidGenerator")
 * @Column("uuid", length = 22)
 * private String uuid;
 */
public final class Base64UuidGenerator implements IdentifierGenerator {

	@Override
	public Serializable generate(SessionImplementor session, Object object) throws HibernateException {
		return UuidUtils.compressRandom();
	}

}
