package com.theboboy.tools.dbadmin.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Table implements Serializable {

	private static final long serialVersionUID = 76918515590985336L;

	private String name;

	private String comment;

	private String pk;

	private ArrayList<Column> columns = new ArrayList<Column>();

	public Table addColumn(Column column) {
		columns.add(column);
		return this;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getPk() {
		return pk;
	}

	public void setPk(String pk) {
		this.pk = pk;
	}

	public ArrayList<Column> getColumns() {
		return columns;
	}

	public void setColumns(ArrayList<Column> columns) {
		this.columns = columns;
	}

}
