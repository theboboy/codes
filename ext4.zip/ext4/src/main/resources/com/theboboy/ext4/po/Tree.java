package com.theboboy.ext4.po;

import java.util.ArrayList;
import java.util.HashMap;

import com.theboboy.ext4.entity.Menu;

public class Tree {

	private TreeNode root;

	public Tree() {
		root = new TreeNode();
	}

	public Tree constructByMenus(ArrayList<Menu> menus) {
		
		int size = menus.size();
		
		HashMap<String, TreeNode> map = new HashMap<String, TreeNode>(size * 4 / 3 + 1);
		
		Menu m = null;
		
		TreeNode value = null, parent = null;
		
		while(map.size() < size) {
		
			for(int i = 0; i < size; i++) {
				
				m = menus.get(i);
				
				value = map.get(m.getId());
				
				if(value != null) {
					continue;
				}
				
				TreeNode node = new TreeNode();
				
				parent = m.getPid() == null ? root : map.get(m.getPid());
				
				if(parent == null) {
					continue;
				}
				
				node.setMenu(m);
				
				parent.addChild(node);
				
				map.put(m.getId(), node);
				
			}
		
		}
		
		map.clear();
		
		return this;
	}

	public TreeNode getRoot() {
		return this.root;
	}

}
