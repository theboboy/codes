package com.theboboy.tools.dbadmin.dialect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

public class MySQLDialect implements Dialect {

	private static String CONNECTION_STRING_TEMPLATE = "jdbc:mysql://${host}:${port}/${db_name}?useUnicode=true&characterEncoding=utf8&transformedBitIsBoolean=yes&autoReconnect=true";

	@Override
	public int getDefaultPort() {
		return 3306;
	}
	
	@Override
	public String getConnectionString(String host, String database) {
		return getConnectionString(host, getDefaultPort(), database);
	}

	@Override
	public String getConnectionString(String host, int port, String database) {
		StringBuilder builder = new StringBuilder(CONNECTION_STRING_TEMPLATE);
		int index = -1;
		builder.replace(index = builder.indexOf("${host}"), index + "${host}".length(), host);
		builder.replace(index = builder.indexOf("${port}"), index + "${port}".length(), Integer.toString(port));
		builder.replace(index = builder.indexOf("${db_name}"), index + "${db_name}".length(), database);
		return builder.toString();
	}

	@Override
	public Connection newConnection(String connectionString, String username,
			String password) {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
		
		if(password == null) {
			password = "";
		}
		
		try {
			return DriverManager.getConnection(connectionString, username, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public ArrayList<String> getTableNames(Connection conn, String schema) {
		String sql = "show tables";
		
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			
			ArrayList<String> tableNames = new ArrayList<String>();
			
			while(rs.next()) {
				tableNames.add(rs.getString(1));
			}
			
			return tableNames;
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return null;
	}

	@Override
	public String getTableComment(Connection conn, String schema,
			String tableName) {
		String sql = "select table_comment from information_schema.tables where table_schema=? and table_name=?";
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, schema);
			stmt.setString(2, tableName);
			rs = stmt.executeQuery();
			String comment = rs.next() ? rs.getString(1) : tableName;
			return comment;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return tableName;
	}
	
	@Override
	public ArrayList<String> getTableComments(Connection conn, String schema, ArrayList<String> tableNames) {
		
		String sql = "select table_name, table_comment from information_schema.tables where table_schema=?";
		
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.prepareStatement(sql);
			
			stmt.setString(1, schema);
			
			rs = stmt.executeQuery();
			
			int size = tableNames.size();
			
			HashMap<String, String> map = new HashMap<String, String>(size);
			
			while(rs.next()) {
				String s1 = rs.getString(1);
				String s2 = rs.getString(2);
				
				map.put(s1, s2);
			}
			
			ArrayList<String> comments = new ArrayList<String>(size);
			
			String name = null;
			
			for(int i = 0; i < size; i++) {
				name = tableNames.get(i);
				String comment = map.get(name);
				if(comment == null || comment.length() == 0) {
					comment = name;
				}
				comments.add(comment);
			}
			
			return comments;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return tableNames;
	}

	@Override
	public String createQueryString(String tableName) {
		StringBuilder builder = new StringBuilder();
		builder.append("select * from ");
		builder.append(tableName);
		return builder.toString();
	}

	@Override
	public String createPageQueryString(String queryString, String pk, int start,
			int limit) {
		StringBuilder builder = new StringBuilder();
		builder.append(queryString);
		builder.append(" limit ");
		builder.append(start);
		builder.append(", ");
		builder.append(limit);
		return builder.toString();
	}

	@Override
	public ArrayList<ArrayList<Object>> executeProc(Connection conn, String procName,
			Object... values) {
		// TODO Auto-generated method stub
		return null;
	}

}
