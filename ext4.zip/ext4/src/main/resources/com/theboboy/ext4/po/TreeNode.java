package com.theboboy.ext4.po;

import java.util.HashMap;
import java.util.LinkedList;

import com.theboboy.ext4.entity.Menu;

public class TreeNode {

	private String id;
	
	private String text;
	
	private boolean leaf;
	
	private Boolean checked;
	
	private String iconCls;
	
	private LinkedList<TreeNode> children = new LinkedList<TreeNode>();

	private HashMap<String, Object> info = new HashMap<String, Object>(0);

	public TreeNode() {
	}

	public TreeNode setMenu(Menu menu) {
		
		this.id = menu.getId();
		
		this.text = menu.getName();
		
		this.addInfo("path", menu.getPath());
		
		return this;
		
	}
	
	public TreeNode addChild(TreeNode node) {
		children.add(node);
		return this;
	}

	public TreeNode addInfo(String key, Object value) {
		info.put(key, value);
		return this;
	}

	/////////////////////////////////////////
	//               Getters               //
	/////////////////////////////////////////
	//<--15 spaces-->       <--15 spaces-->//
	
	public String getId() {
		return id;
	}

	public String getText() {
		return text;
	}

	public boolean isLeaf() {
		leaf = children.isEmpty();
		return leaf;
	}

	public Boolean getChecked() {
		return checked;
	}

	public String getIconCls() {
		return iconCls;
	}

	public LinkedList<TreeNode> getChildren() {
		return children;
	}

	public HashMap<String, Object> getInfo() {
		return info;
	}

}
