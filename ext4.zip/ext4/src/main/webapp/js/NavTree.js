Ext.define(namespace + '.NavTree', {
  
  extend: 'Ext.tree.Panel',
  
  autoHeight: true,
  
  autoScroll: true,
  
  enableDD: false,
  
  //baseCls: 'x-plain',
  
  rootVisible: false,
  
  store: Ext.create('Ext.data.TreeStore', {
    proxy: {
      type: 'ajax',
      url: 'menu/tree'
    },
    root: {
      text: '所有菜单',
      expanded: true
    }
  }),
  
  afterrender: function(tree, eOpts) {
    this.expandAll();
  },
  
  click: function(view, record, item, index, e, eOpts) {
    
    //var node = record.data;
    
    var leaf = record.get('leaf');
    
    if(leaf) {
      
      var tabs = Ext.getCmp('mainTabs');
      
      var text = record.get('text');
      
      var tabId = 'tab-' + text, tab;
      
      if(tab = Ext.getCmp(tabId)) {
        tabs.setActiveTab(tab);
      } else {
        
        var module = record.raw.info.path;
        
        module = namespace + '.' + module;

        /*Ext.require(module, function() {
          Ext.create(module);
        });*/
        
        tabs.add({
          id: tabId,
          title: text,
          closable: true
        }).show();
      }
      
    } else {
      var isExpanded = record.get('expanded');
      if(isExpanded) {
        view.collapse(record);
      } else {
        view.expand(record);
      }
    }
    
  },
  
  initComponent: function() {
    
    this.callParent();
    
    this.on('afterrender', this.afterrender);
    
    this.on('itemclick', this.click);
    
    /*this.on('remove', function(ct, tab) {
      this.remove(tab);
    });*/
    
  }
  
});