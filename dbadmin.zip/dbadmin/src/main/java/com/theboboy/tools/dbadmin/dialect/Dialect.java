package com.theboboy.tools.dbadmin.dialect;

import java.sql.Connection;
import java.util.ArrayList;

public interface Dialect {

	int getDefaultPort();

	String getConnectionString(String host, String database);
	
	String getConnectionString(String host, int port, String database);
	
	Connection newConnection(String connectionString, String username, String password);
	
	ArrayList<String> getTableNames(Connection conn, String schema);
	
	String getTableComment(Connection conn, String schema, String tableName);
	
	ArrayList<String> getTableComments(Connection conn, String schema, ArrayList<String> tableNames);

	String createQueryString(String tableName);

	String createPageQueryString(String tableName, String pk, int start, int limit);

	ArrayList<ArrayList<Object>> executeProc(Connection conn, String procName, Object... values);

}
