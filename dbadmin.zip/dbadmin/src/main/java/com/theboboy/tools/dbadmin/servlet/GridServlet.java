package com.theboboy.tools.dbadmin.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.theboboy.tools.dbadmin.dialect.Dialect;
import com.theboboy.tools.dbadmin.model.Column;
import com.theboboy.tools.dbadmin.model.Table;
import com.theboboy.tools.dbadmin.util.DBUtils;
import com.theboboy.tools.dbadmin.util.NameUtils;
import com.theboboy.tools.dbadmin.util.PropertyMgr;

@SuppressWarnings({ "rawtypes", "unchecked" })
public class GridServlet extends HttpServlet {

	private static final long serialVersionUID = -7753883061148365496L;

	protected static String URL = null;

	private Dialect dialect;
	
	private String encoding;
	
	private boolean useCache;
//	
	private String tpl;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		String uc = config.getInitParameter("useCache");
		
		if(uc == null || uc.length() == 0) {
			uc = config.getServletContext().getInitParameter("useCache");
		}
		
		if(uc == null || uc.length() == 0) {
			useCache = true;
		} else if("true".equalsIgnoreCase(uc)) {
			useCache = true;
		} else if("false".equalsIgnoreCase(uc)) {
			useCache = false;
		} else {
			throw new ServletException("useCache must be a boolean value");
		}
		
		String dialectName = config.getInitParameter("dialect");
		
		if(dialectName == null || dialectName.length() == 0) {
			dialectName = config.getServletContext().getInitParameter("dialect");
			if(dialectName == null || dialectName.length() == 0) {
				throw new ServletException("dialect is null or empty");
			}
		}
		
		try {
			Class c = Class.forName(dialectName);
			dialect = (Dialect) c.newInstance();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		
		this.encoding = config.getInitParameter("encoding");
		
		if(encoding == null || encoding.length() == 0) {
			encoding = config.getServletContext().getInitParameter("encoding");
			if(encoding == null || encoding.length() == 0) {
				encoding = "UTF-8";
			}
		}
		
		InputStream is = this
				.getClass()
				.getClassLoader()
				.getResourceAsStream(
						"template/grid.js");
		
		InputStreamReader isr = null;
		
		try {
			isr = new InputStreamReader(is, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		BufferedReader br = new BufferedReader(isr);
		StringBuffer buffer = new StringBuffer();
		
		String temp = null;
		
		try {
			while((temp = br.readLine()) != null) {
				buffer.append(temp);
				buffer.append("\r\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if(br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(isr != null) {
				try {
					isr.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(is != null) {
				try {
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		tpl = buffer.toString();
	}
	
	@Override
	public void destroy() {
		super.destroy();
	}
	
	private Connection getConnection(String db) {
		return dialect.newConnection(PropertyMgr.getUrl(db), PropertyMgr.getUser(db), PropertyMgr.getPwd(db));
	}

	private Table getTable(String db, String tableName) {
		Connection conn = getConnection(db);
		Table table = DBUtils.getTable(dialect, conn, PropertyMgr.getSchema(db), tableName, useCache);
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return table;
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding(encoding);
		response.setCharacterEncoding(encoding);
		
		if(URL == null) {
			URL = request.getRequestURI();
		}
		
		String method = request.getParameter("method");
		
		if(method == null || method.length() == 0) {
			page(request, response);
		} else if("list".equals(method)){
			list(request, response);
		} else if("add".equals(method)){
			add(request, response);
		} else if("modify".equals(method)){
			modify(request, response);
		} else if("load".equals(method)){
			load(request, response);
		} else if("remove".equals(method)){
			remove(request, response);
		} else {
			error(request, response);
		}
	}

	/**
	 * 生成网页
	 */
	private void page(HttpServletRequest request, HttpServletResponse response) {
		String db = request.getParameter("db");
		Table table = getTable(db, request.getParameter("table"));
		
		StringBuffer buffer = new StringBuffer(tpl);
		
		int index = -1;

		String tableNameUpper = NameUtils.hungaryToCamelCase(table.getName(), true);
		String tableNameLower = NameUtils.hungaryToCamelCase(table.getName(), false);

		int upperLen = "${table_name_upper}".length();
		int lowerLen = "${table_name_lower}".length();

		while((index = buffer.indexOf("${table_name_upper}")) > -1) {
			buffer.replace(index, index + upperLen, tableNameUpper);
		}

		while((index = buffer.indexOf("${table_name_lower}")) > -1) {
			buffer.replace(index, index + lowerLen, tableNameLower);
		}

		int len = "${base_url}".length();
		while((index = buffer.indexOf("${base_url}")) > -1) {
			buffer.replace(index, index + len, URL + "?db=" + db + "&table=" + table.getName());
		}

		len = "${table_comment}".length();
		String comment = table.getComment();
		if(comment == null || comment.length() == 0) {
			comment = table.getName();
		}
		while((index = buffer.indexOf("${table_comment}")) > -1) {
			buffer.replace(index, index + len, table.getName());
		}

		index = buffer.indexOf("${page_size}");
		buffer.replace(index, index + "${page_size}".length(), "30");

		StringBuffer columns = new StringBuffer();
		
		ArrayList<Column> list = table.getColumns();
		
		for(int i = 0, size = list.size(); i < size; i++) {
			columns.append(getColumn(list.get(i)));
			columns.append(',');
		}
		if(columns.length() > 0) {
			columns.deleteCharAt(columns.length() - 1);
		}
		
		index = buffer.indexOf("${columns}");
		buffer.replace(index, index + "${columns}".length(), columns.toString());

		response.setHeader("Accept-Ranges", "bytes");
		response.setHeader("Connection", "Keep-Alive");
		response.setHeader("Content-Type", "text/javascript");
		response.setHeader("Content-Disposition", "filename=grid.js");
		try {
			PrintWriter out = response.getWriter();
			out.println(buffer.toString());
			out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private String getColumn(Column column) {
		String xtype = convertType(column.getType());

		StringBuilder bufffer = new StringBuilder(256);
		bufffer.append('{');
		bufffer.append("header: ");
		bufffer.append('\'');
//		if(column.getComment() != null && column.getComment().length() > 0) {
//			bufffer.append(column.getComment());
//		} else {
//			bufffer.append(column.getName());
//		}
		bufffer.append(column.getName());
		bufffer.append('\'');
		bufffer.append(',');
		bufffer.append("dataIndex: ");
		bufffer.append('\'');
		if(column.isPk()) {
			bufffer.append("id");
		} else {
			bufffer.append(column.getName());
		}
		bufffer.append('\'');
		bufffer.append(',');

		bufffer.append("fieldLabel: ");
		bufffer.append('\'');
//		if(column.getComment() != null && column.getComment().length() > 0) {
//			bufffer.append(column.getComment());
//		} else {
//			bufffer.append(column.getName());
//		}
		bufffer.append(column.getName());
		bufffer.append('\'');
		bufffer.append(',');


		if(column.isAuto()) {
			bufffer.append("autoIncr: true");
			bufffer.append(',');
		}

		if("numberfield".equals(xtype) && column.getName().toLowerCase().startsWith("is_")) {
			xtype = "radiogroup";
		}

		if("radiogroup".equals(xtype)) {
			bufffer.append("name: ");
			bufffer.append('\'');
			bufffer.append(column.getName());
			bufffer.append('_');
			bufffer.append(column.getName());
			bufffer.append('\'');
			bufffer.append(',');
			bufffer.append("items: [{name: '");
			bufffer.append(column.getName());
			bufffer.append("', boxLabel: '是', inputValue: 1, checked: true, xtype: 'radio'}, {name: '");
			bufffer.append(column.getName());
			bufffer.append("', boxLabel: '否', inputValue: 0, xtype: 'radio'}],");
		} else if("combo".equals(xtype)) {
		} else {
			//可能是hiddenName
			bufffer.append("name: ");
			bufffer.append('\'');
			bufffer.append(column.getName());
			bufffer.append('\'');
			bufffer.append(',');
		}

		if("textfield".equals(xtype) || "numberfield".equals(xtype) || "datefield".equals(xtype)) {
			if(column.isNotnull()) {
				bufffer.append("allowBlank: false");
				bufffer.append(',');
			}
			if("datefield".equals(xtype)) {
				bufffer.append("editable: false, format: 'Y-m-d'");
				bufffer.append(',');
			}
		}

		bufffer.append("xtype: ");
		bufffer.append('\'');
		bufffer.append(xtype);
		bufffer.append('\'');

		if(1 > 0) {
			//别的东西
		}

		bufffer.append('}');
		return bufffer.toString();
	}

	private String convertType(String dbType) {
		String xtype = "textfield";

		String upper = dbType.toUpperCase();

		Set<String> numberSet = new HashSet<String>();
		numberSet.add("TINYINT");
		numberSet.add("INT");
		numberSet.add("BIGINT");
		numberSet.add("INTEGER");
		numberSet.add("LONG");
		numberSet.add("FLOAT");
		numberSet.add("DOUBLE");
		numberSet.add("DECIMAL");
		numberSet.add("NUMERIC");

		if(numberSet.contains(upper)) {
			xtype = "numberfield";
		}else if("BOOLEAN".equals(upper) || "BIT".equals(upper)) {
			xtype = "radiogroup";
		} else if("DATE".equals(upper) || "TIME".equals(upper) || "DATETIME".equals(upper) || "TIMESTAMP".equals(upper)) {
			xtype = "datefield";
		} else if("ENUM".equals(upper)) {
			xtype = "combo";
		}
		return xtype;
	}

	/**
	 * 查询
	 */
	private void list(HttpServletRequest request, HttpServletResponse response) {
		String db = request.getParameter("db");
		String tableName = request.getParameter("table");
		String query = request.getParameter("query");
		int start = Integer.parseInt(request.getParameter("start"));
		int limit = Integer.parseInt(request.getParameter("limit"));

		Table table = getTable(db, request.getParameter("table"));

		String sql = "select _ from " + tableName;
		if(query != null && query.length() > 0) {
			StringBuffer buffer = new StringBuffer(sql);
			buffer.append(" where ");
			boolean isFirst = true;
			ArrayList<Column> columns = table.getColumns();
			Column column = null;
			for(int i = 0, size = columns.size(); i < size; i++) {
				column = columns.get(i);
				if(!isFirst) {
					buffer.append(" or ");
				}
				buffer.append(column.getName());
				buffer.append(" like '%");
				buffer.append(query);
				buffer.append("%'");
				isFirst = false;
			}
			sql = buffer.toString();
		}

		String selectSql = dialect.createPageQueryString(sql.replaceFirst("_", "*"), table.getPk(), start, limit);
		String countSql = sql.replaceFirst("_", "count(1)");
		
		LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();

		boolean success = false;

		Statement stmt = null;
		ResultSet rs = null;
		
		Connection conn = getConnection(db);
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(countSql);
			if(rs.next()) {
				map.put("totalCount", rs.getLong(1));
			}
			success = true;
		} catch (SQLException e) {
			success = false;
			e.printStackTrace();
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		conn = getConnection(db);
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(selectSql);
			LinkedList<LinkedHashMap<String, String>> list = new LinkedList<LinkedHashMap<String, String>>();
			while(rs.next()) {
				LinkedHashMap<String, String> obj = new LinkedHashMap<String, String>();
				ArrayList<Column> columns = table.getColumns();
				Column column = null;
				for(int i = 0, size = columns.size(); i < size; i++) {
					column = columns.get(i);
					String value = rs.getString(column.getName());
					if("datefield".equals(convertType(column.getType())) && value != null && value.indexOf(' ') > 0) {
						value = value.substring(0, value.indexOf(' '));
					} else if("radiogroup".equals(convertType(column.getType()))) {
						if("0".equals(value ) || "false".equals(value)) {
							value = "否";
						} else {
							value = "是";
						}
					}
					if(column.isPk()) {
						obj.put("id", value);
					}
					obj.put(column.getName(), value);
				}
				list.add(obj);
			}
			map.put("list", list);
			success = true;
		} catch (SQLException e) {
			success = false;
			throw new RuntimeException(selectSql);
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		map.put("success", success);
		response.setContentType("text/plain");
		try {
			String json = JSON.toJSONString(map);
			
			json = json.replaceAll("<", "&lt").replaceAll(">", "&gt;");
			
			PrintWriter out = response.getWriter();
			out.println(json);
			out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 添加
	 */
	private void add(HttpServletRequest request, HttpServletResponse response) {
		String db = request.getParameter("db");
		Table table = getTable(db, request.getParameter("table"));
		StringBuffer buffer = new StringBuffer();
		buffer.append("insert into ");
		buffer.append(table.getName());
		buffer.append("(");
		ArrayList<Column> columns = table.getColumns();
		Column column = null;
		for(int i = 0, size = columns.size(); i < size; i++) {
			column = columns.get(i);
			//分析
			if(!column.isAuto()) {
				buffer.append(column.getName());
				buffer.append(',');
			}
		}
		buffer.deleteCharAt(buffer.length() - 1);
		buffer.append(") values (");
		for(int i = 0, size = columns.size(); i < size; i++) {
			column = columns.get(i);
			String value = request.getParameter(column.getName());
			//分析
			if(!column.isAuto()) {
				String xtype = convertType(column.getType());
				if(value == null || value.length() == 0) {
					buffer.append("null");
				} else {
					if("radiogroup".equals(xtype) || "numberfield".equals(xtype)) {
						buffer.append(value);
					} else {
						buffer.append('\'');
						buffer.append(value);
						buffer.append('\'');
					}
				}
				buffer.append(',');
			}
		}
		buffer.deleteCharAt(buffer.length() - 1);
		buffer.append(")");
		String sql = buffer.toString();
		Statement stmt = null;
		
		LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
		boolean success = false;
		
		Connection conn = getConnection(db);
		try {
			stmt = conn.createStatement();
			int rows = stmt.executeUpdate(sql);
			map.put("success", success = rows > 0);
			map.put("msg", success ? "添加成功!" : "添加失败!");
		} catch (SQLException e) {
			map.put("success", false);
			map.put("msg", e.getMessage());
			e.printStackTrace();
		} finally {
			if(stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		outputJson(response, map, success);
	}

	/**
	 * 修改
	 */
	private void modify(HttpServletRequest request, HttpServletResponse response) {
		String db = request.getParameter("db");
		Table table = getTable(db, request.getParameter("table"));
		HashMap<String, String> types = new HashMap<String, String>(table.getColumns().size());
		String idXtype = null;
		ArrayList<Column> columns = table.getColumns();
		Column column = null;
		for(int i = 0, size = columns.size(); i < size; i++) {
			column = columns.get(i);
			if(column.isPk()) {
				idXtype = convertType(column.getType());
			} else {
				types.put(column.getName(), column.getType());
			}
		}
		Map<String, String[]> params = request.getParameterMap();
		StringBuffer buffer = new StringBuffer();
		buffer.append("update ");
		buffer.append(table.getName());
		buffer.append(" set ");
		Set<String> set = params.keySet();
		String id = null;
		for(String key : set) {
			if("id".equals(key)) {
				id = params.get(key)[0];
				continue;
			}
			if(types.containsKey(key)) {
				String[] value = params.get(key);
				buffer.append(key);
				buffer.append("=");
				if(value == null || value.length == 0 || value[0] == null || value[0].length() == 0) {
					buffer.append("null");
				} else {
					String xtype = convertType(types.get(key));
					if("radiogroup".equals(xtype) || "numberfield".equals(xtype)) {
						buffer.append(value[0]);
					} else {
						buffer.append('\'');
						buffer.append(value[0]);
						buffer.append('\'');
					}
				}
				buffer.append(',');
			}
		}
		buffer.deleteCharAt(buffer.length() - 1);
		buffer.append(" where ");
		buffer.append(table.getPk());
		buffer.append("=");

		if("radiogroup".equals(idXtype) || "numberfield".equals(idXtype)) {
			buffer.append(id);
		} else {
			buffer.append('\'');
			buffer.append(id);
			buffer.append('\'');
		}
		String sql = buffer.toString();
		Statement stmt = null;
		
		LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
		boolean success = false;
		
		Connection conn = getConnection(db);
		try {
			stmt = conn.createStatement();
			int rows = stmt.executeUpdate(sql);
			map.put("success", success = rows > 0);
			map.put("msg", success ? "修改成功!" : "修改失败!");
		} catch (SQLException e) {
			map.put("success", false);
			map.put("msg", e.getMessage());
			e.printStackTrace();
		} finally {
			if(stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		outputJson(response, map, success);
	}

	/**
	 * 查看
	 */
	private void load(HttpServletRequest request, HttpServletResponse response) {
		String db = request.getParameter("db");
		Table table = getTable(db, request.getParameter("table"));
		String id = request.getParameter("id");
		StringBuffer buffer = new StringBuffer();
		buffer.append("select * from ");
		buffer.append(table.getName());
		buffer.append(" where ");
		buffer.append(table.getPk());
		buffer.append("=");
		String xtype = null;
		ArrayList<Column> columns = table.getColumns();
		Column column = null;
		for(int i = 0, size = columns.size(); i < size; i++) {
			column = columns.get(i);
			if(table.getPk().equals(column.getName())) {
				xtype = convertType(column.getType());
				break;
			}
		}
		if("numberfield".equals(xtype)) {
			buffer.append(id);
		} else {
			buffer.append('\'');
			buffer.append(id);
			buffer.append('\'');
		}
		String sql = buffer.toString();
		Statement stmt = null;
		ResultSet rs = null;
		
		LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
		boolean success = false;
		
		Connection conn = getConnection(db);
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			LinkedHashMap<String, String> data = new LinkedHashMap<String, String>();
			while(rs.next()) {
				success = true;
				for(int i = 0, size = columns.size(); i < size; i++) {
					column = columns.get(i);
					data.put(column.getName(), rs.getString(column.getName()));
				}
			}
			map.put("success", success);
			if(success) {
				data.put("id", data.get(table.getPk()));
				map.put("data", data);

			} else {
				map.put("msg", "Cannot Load Such Entity with Identifier: " + id);
			}
		} catch (SQLException e) {
			map.put("success", false);
			map.put("msg", "Cannot Load Such Entity with Identifier: " + id);
			e.printStackTrace();
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		outputJson(response, map, success);
	}

	/**
	 * 删除
	 */
	private void remove(HttpServletRequest request, HttpServletResponse response) {
		String db = request.getParameter("db");
		Table table = getTable(db, request.getParameter("table"));
		String idXtype = null;
		boolean isNumber = true;
		ArrayList<Column> columns = table.getColumns();
		Column column = null;
		for(int i = 0, size = columns.size(); i < size; i++) {
			column = columns.get(i);
			if(column.isPk()) {
				idXtype = convertType(column.getType());
				isNumber = "numberfield".equals(idXtype);
				break;
			}
		}
		StringBuffer buffer = new StringBuffer();
		buffer.append("delete from ");
		buffer.append(table.getName());
		buffer.append(" where ");
		buffer.append(table.getPk());
		buffer.append(" in (");
		String[] ids = request.getParameterValues("id");
		if(isNumber) {
			for(int i = 0, len = ids.length; i < len; i++) {
				buffer.append(ids[i]);
				buffer.append(',');
			}
		} else {
			for(int i = 0, len = ids.length; i < len; i++) {
				buffer.append('\'');
				buffer.append(ids[i]);
				buffer.append('\'');
				buffer.append(',');
			}

		}
		buffer.deleteCharAt(buffer.length() - 1);
		buffer.append(")");
		String sql = buffer.toString();
		Statement stmt = null;
		
		LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
		boolean success = false;
		
		Connection conn = getConnection(db);
		try {
			stmt = conn.createStatement();
			int rows = stmt.executeUpdate(sql);
			map.put("success", success = rows > 0);
			map.put("msg", success ? "删除成功!" : "删除失败!");
		} catch (SQLException e) {
			map.put("success", false);
			map.put("msg", e.getMessage());
			e.printStackTrace();
		} finally {
			if(stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		outputJson(response, map, success);
	}

	private void error(HttpServletRequest request, HttpServletResponse response) {
	}

	private void outputJson(HttpServletResponse response, Object obj, boolean success) {
		if(!success) {
			response.setStatus(600);
		}
		response.setContentType("text/plain");
		try {
			PrintWriter out = response.getWriter();
			out.print(JSON.toJSONString(obj));
			out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
