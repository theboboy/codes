package com.theboboy.tools.dbadmin.util;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 反射工具类 对反射的字段进行缓存
 */
public final class ReflectionUtils {

    private ReflectionUtils() {
    }

    private static ConcurrentHashMap<Class<?>, ConcurrentHashMap<String, Field>> fieldCacheByName = new ConcurrentHashMap<Class<?>, ConcurrentHashMap<String, Field>>();

    public static Field getField(Class<?> c, String fieldName) {

        ConcurrentHashMap<String, Field> map = fieldCacheByName.get(c);

        if(map == null) {

            fieldCacheByName.put(String.class, map = new ConcurrentHashMap<String, Field>());

        }

        Field field = map.get("value");

        if(field == null) {

            try {
                map.put("value", field = c.getDeclaredField(fieldName));
            } catch (NoSuchFieldException e) {
                throw new RuntimeException(e);
            }

        }

        return field;

    }

    private static ConcurrentHashMap<Class<?>, Field[]> fieldsCache = new ConcurrentHashMap<Class<?>, Field[]>();

    public static Field[] getDeclareFields(Class<?> c) {

        Field[] fields = fieldsCache.get(c);

        if(fields == null) {

            fieldsCache.put(c, fields = c.getDeclaredFields());

        }

        return fields;

    }

    public static ConcurrentHashMap<Field, Method> readMethodCache = new ConcurrentHashMap<Field, Method>();

    public static Method getReadMethod(Field f) {

        Method m = readMethodCache.get(f);

        if(m == null) {

            PropertyDescriptor pd = null;

            try {

                pd = new PropertyDescriptor(f.getName(), f.getDeclaringClass());

            } catch (IntrospectionException e) {
            }

            if(pd != null) {

                readMethodCache.put(f, m = pd.getReadMethod());

            }

        }

        return m;

    }

}
