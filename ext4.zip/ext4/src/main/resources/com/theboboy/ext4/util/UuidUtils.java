package com.theboboy.ext4.util;

import java.util.UUID;

public final class UuidUtils {

	private UuidUtils() {
	}

	public static String compressRandom() {
		return compressUUID(UUID.randomUUID());
	}

	public static String compressUUID(UUID uuid) {
		byte[] byUuid = new byte[16];
		long least = uuid.getLeastSignificantBits();
		long most = uuid.getMostSignificantBits();
		long2bytes(most, byUuid, 0);
		long2bytes(least, byUuid, 8);
		String compressUUID = new Base64Encoder().encode(byUuid);
		return compressUUID.substring(0, 22);
	}

	// public static UUID uncompressBase64(String compressedUuid) {
	// byte[] byUuid = Base64.decodeBase64(compressedUuid + "==");
	// long most = bytes2long(byUuid, 0);
	// long least = bytes2long(byUuid, 8);
	// return new UUID(most, least);
	// }

	private static void long2bytes(long value, byte[] bytes, int offset) {
		for (int i = 7; i > -1; i--) {
			bytes[offset++] = (byte) ((value >> 8 * i) & 0xFF);
		}
	}

	// private static long bytes2long(byte[] bytes, int offset) {
	// long value = 0;
	// for (int i = 7; i > -1; i--) {
	// value |= (((long) bytes[offset++]) & 0xFF) << 8 * i;
	// }
	// return value;
	// }

}
