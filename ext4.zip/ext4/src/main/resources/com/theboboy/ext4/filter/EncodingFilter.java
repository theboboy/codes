package com.theboboy.ext4.filter;
import java.io.IOException;
import java.nio.charset.Charset;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class EncodingFilter implements Filter {

	private static final String DEFAULT_ENCODING = "UTF-8";

	private String encoding;

	private static String APP_PATH = null;

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		String enc = filterConfig.getInitParameter("encoding");
		
		if(enc != null && enc.length() > 0) {
			Charset cs = Charset.forName(enc);
			if(cs != null) {
				encoding = enc;
			}
		}
		
		if(encoding == null) {
			encoding = DEFAULT_ENCODING;
		}
		
		APP_PATH = filterConfig.getServletContext().getRealPath("/");
		
		System.out.println("-----------------------------" + APP_PATH);
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {

		request.setCharacterEncoding(encoding);

		response.setCharacterEncoding(encoding);
		
		chain.doFilter(request, response);

	}

	@Override
	public void destroy() {
	}

	public static String getAppPath() {
		return APP_PATH;
	}

}
