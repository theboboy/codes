package com.theboboy.tools.dbadmin.util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Json类
 * 368行Object value = f.get(obj);可以优化
 * TODO 考虑加入循环引用检测 需求不是特别大
 * TODO 数据量大时效率变慢 可能和内存的控制有关（方法栈）
 *                         也有可能是没用到StringWriter
 */
public final class Json {

    private Json() {
    }

    public static String toJsonString(Object obj) {
        return String.valueOf(internalToJsonString(obj, new StringBuilder()));
    }

    private static StringBuilder internalToJsonString(Object obj, StringBuilder buffer) {

        if(obj == null) {

            return null;

        }

        StringBuilder builder = new StringBuilder();

        Class c = obj.getClass();

        if(Map.class.isAssignableFrom(c)) {

            builder.append("{");

            Set<Map.Entry> entries = ((Map) obj).entrySet();

            Object key, value;

            int i = 0;

            for(Map.Entry entry : entries) {

                if(i != 0) {

                    builder.append(",");

                }

                key = entry.getKey();

                value = entry.getValue();

                builder.append("\"");

                builder.append(escapeString(String.valueOf(key), buffer, false));

                builder.append("\":");

                builder.append(internalToJsonString(value, buffer));

                i = 1;

            }

            builder.append("}");

        } else if(Iterable.class.isAssignableFrom(c)) {

            builder.append("[");

            if(ArrayList.class.isAssignableFrom(c)) {

                ArrayList list = (ArrayList) obj;

                Object item = null;

                for(int i = 0, size = list.size(); i < size; i++) {

                    if(i != 0) {

                        builder.append(",");

                    }

                    item = list.get(i);

                    builder.append(internalToJsonString(item, buffer));

                }

            } else {

                Iterable list = (Iterable) obj;

                int i = 0;

                for(Object item : list) {

                    if(i != 0) {

                        builder.append(",");

                    }

                    builder.append(internalToJsonString(item, buffer));

                    i = 1;

                }

            }

            builder.append("]");

        } else if(c.isArray()) {

            builder.append("[");

            Class z = c.getComponentType();

            if(z == byte.class) {

                byte[] arr = (byte[]) obj;

                for(int i = 0, len = arr.length; i < len; i++) {

                    if(i != 0) {

                        builder.append(",");

                    }

                    builder.append(internalToJsonString(arr[i], buffer));

                }

            } else if(z == short.class) {

                short[] arr = (short[]) obj;

                for(int i = 0, len = arr.length; i < len; i++) {

                    if(i != 0) {

                        builder.append(",");

                    }

                    builder.append(internalToJsonString(arr[i], buffer));

                }

            } else if(z == int.class) {

                int[] arr = (int[]) obj;

                for(int i = 0, len = arr.length; i < len; i++) {

                    if(i != 0) {

                        builder.append(",");

                    }

                    builder.append(internalToJsonString(arr[i], buffer));

                }

            } else if(z == long.class) {

                long[] arr = (long[]) obj;

                for(int i = 0, len = arr.length; i < len; i++) {

                    if(i != 0) {

                        builder.append(",");

                    }

                    builder.append(internalToJsonString(arr[i], buffer));

                }

            } else if(z == float.class) {

                float[] arr = (float[]) obj;

                for(int i = 0, len = arr.length; i < len; i++) {

                    if(i != 0) {

                        builder.append(",");

                    }

                    builder.append(internalToJsonString(arr[i], buffer));

                }

            } else if(z == double.class) {

                double[] arr = (double[]) obj;

                for(int i = 0, len = arr.length; i < len; i++) {

                    if(i != 0) {

                        builder.append(",");

                    }

                    builder.append(internalToJsonString(arr[i], buffer));

                }

            } else if(z == boolean.class) {

                boolean[] arr = (boolean[]) obj;

                for(int i = 0, len = arr.length; i < len; i++) {

                    if(i != 0) {

                        builder.append(",");

                    }

                    builder.append(internalToJsonString(arr[i], buffer));

                }

            } else if(z == char.class) {

                char[] arr = (char[]) obj;

                for(int i = 0, len = arr.length; i < len; i++) {

                    if(i != 0) {

                        builder.append(",");

                    }

                    builder.append(internalToJsonString(arr[i], buffer));

                }

            } else {

                Object[] arr = (Object[]) obj;

                for(int i = 0, len = arr.length; i < len; i++) {

                    if(i != 0) {

                        builder.append(",");

                    }

                    builder.append(internalToJsonString(arr[i], buffer));

                }

            }

            builder.append("]");

        } else {

            boolean needQuotation = true, basic = false;

            if(c == byte.class || c == short.class || c == int.class || c == long.class || c == float.class || c == double.class) {

                basic = true;

                needQuotation = false;

            } else if(Number.class.isAssignableFrom(c)) {

                basic = true;

                needQuotation = false;

            } else if(c == boolean.class || c == Boolean.class) {

                basic = true;

                needQuotation = false;

            } else if(c == char.class || c == Character.class) {

                basic = true;

                needQuotation = true;

            } else if(CharSequence.class.isAssignableFrom(c)) {

                basic = true;

                needQuotation = true;

            }

            if(basic) {

                if(!needQuotation) {

                    builder.append(obj);

                } else {

                    builder.append("\"");

                    builder.append(escapeString(String.valueOf(obj), buffer, false));

                    builder.append("\"");

                }

            } else if(Date.class.isAssignableFrom(c)) {

                builder.append("\"");

                builder.append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format((Date) obj));

                builder.append("\"");

            } else if(Calendar.class.isAssignableFrom(c)) {

                builder.append("\"");

                builder.append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((Calendar) obj).getTime()));

                builder.append("\"");

            } else {

                builder.append("{");

                Field[] fields = ReflectionUtils.getDeclareFields(c);

                Field f;

                try {

                    for(int i = 0, j = 0, len = fields.length; i < len; i++) {

                        f = fields[i];

                        int ms = f.getModifiers();

                        if(!Modifier.isStatic(ms)) {

                            if(Modifier.isPublic(ms)) {

                                if(j != 0) {

                                    builder.append(",");

                                }

                                Object key = f.getName();

                                Object value = f.get(obj);

                                builder.append("\"");

                                builder.append(escapeString(String.valueOf(key), buffer, false));

                                builder.append("\":");

                                builder.append(internalToJsonString(value, buffer));

                                j = 1;

                            } else {

                                Method m = ReflectionUtils.getReadMethod(f);

                                if(m != null && getParameterCount(m) == 0 && Modifier.isPublic(m.getModifiers())) {

                                    if(j != 0) {

                                        builder.append(",");

                                    }

                                    Object key = f.getName();

                                    Object value = null;

                                    value = m.invoke(obj);

                                    builder.append("\"");

                                    builder.append(escapeString(String.valueOf(key), buffer, false));

                                    builder.append("\":");

                                    builder.append(internalToJsonString(value, buffer));

                                    j = 1;

                                }

                            }

                        }

                    }

                } catch (Exception e) {
                }

                builder.append("}");

            }

        }

        return builder;

    }
    
    private static Field parameterTypesField;
    
    static {
    	try {
			parameterTypesField = Method.class.getDeclaredField("parameterTypes");
		} catch (SecurityException e) {
		} catch (NoSuchFieldException e) {
		}
    }
    
    private static int getParameterCount(Method m) {
    	
    	if(parameterTypesField != null) {
    		
    		parameterTypesField.setAccessible(true);
    		
    		try {
				return ((Class[]) parameterTypesField.get(m)).length;
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
    		
    		parameterTypesField.setAccessible(false);
    		
    	}
    	
    	throw new RuntimeException();
    	
    }

    private static String escapeString(String str, StringBuilder builder, boolean escapeSingleQuotes) {
    	
        if (str == null) {
            return null;
        }

        int sz = str.length();

        builder.setLength(0);

        for (int i = 0; i < sz; i++) {

            char ch = str.charAt(i);

            if (ch > 0xfff) {
                builder.append("\\u").append(Integer.toHexString(ch).toUpperCase());
            } else if (ch > 0xff) {
                builder.append("\\u0").append(Integer.toHexString(ch).toUpperCase());
            } else if (ch > 0x7f) {
                builder.append("\\u00").append(Integer.toHexString(ch).toUpperCase());
            } else if (ch < 32) {
                switch (ch) {
                    case '\b':
                        builder.append('\\').append('b');
                        break;
                    case '\n':
                        builder.append('\\').append('n');
                        break;
                    case '\t':
                        builder.append('\\').append('t');
                        break;
                    case '\f':
                        builder.append('\\').append('f');
                        break;
                    case '\r':
                        builder.append('\\').append('r');
                        break;
                    default :
                        if (ch > 0xf) {
                            builder.append("\\u00").append(Integer.toHexString(ch).toUpperCase());
                        } else {
                            builder.append("\\u000").append(Integer.toHexString(ch).toUpperCase());
                        }
                        break;
                }
            } else {
                switch (ch) {
                    case '\'':
                        if (escapeSingleQuotes) {
                            builder.append('\\');
                        }
                        builder.append('\'');
                        break;
                    case '"':
                        builder.append('\\').append('"');
                        break;
                    case '\\':
                        builder.append('\\').append('\\');
                        break;
                    default :
                        builder.append(ch);
                        break;
                }
            }
        }

        return builder.toString();

    }

}
