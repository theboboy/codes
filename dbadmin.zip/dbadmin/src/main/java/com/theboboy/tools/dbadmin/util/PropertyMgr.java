package com.theboboy.tools.dbadmin.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Properties;

public class PropertyMgr {

	static Properties properties = new Properties();
	
	static ArrayList<String> dbs = new ArrayList<String>();

	static {

		try {
			properties.load(PropertyMgr.class.getClassLoader().getResourceAsStream("config.properties"));
		} catch (IOException e) {
			System.out.println("cannot find configuration");
		}
		
		Object[] keys = properties.keySet().toArray();
		
		for(Object key : keys) {
			String k = String.valueOf(key);
			if(k.endsWith("_DB.driver")) {
				dbs.add(k.substring(0, k.length() - "_DB.driver".length()));
			}
		}
		
		Collections.sort(dbs);
		
	}
	
	public static ArrayList<String> getDBs() {
		return dbs;
	}

	public static String getUrl(String db) {
		return properties.getProperty(db + "_DB.url");
	}

	public static String getSchema(String db) {
		String url = getUrl(db);
		String schema = url.substring(url.lastIndexOf('/') + 1);
		int index = schema.indexOf('?');
		if(index > 0) {
			schema = schema.substring(0, index);
		}
		return schema;
	}
	
	public static String getUser(String db) {
		return properties.getProperty(db + "_DB.user");
	}

	public static String getPwd(String db) {
		return properties.getProperty(db + "_DB.password");
	}

}
