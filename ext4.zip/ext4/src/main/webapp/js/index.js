var namespace = 'js';

Ext.Loader.setConfig({ enabled: true });

Ext.Loader.setPath('Ext.ux', 'ext4/ux');

Ext.Loader.setPath(namespace, 'js');

Ext.require([
  namespace + '.TabCloseMenu',
  namespace + '.NavTree'
]);

Ext.onReady(function() {

  Ext.QuickTips.init();

  var viewport = Ext.create('Ext.Viewport', {
    id: 'border-example',
    layout: 'border',
    items: [Ext.create('Ext.Component', {
      region: 'north',
      contentEl: 'north',
      height: 100,
      minSize: 100,
      maxSize: 100,
      margins: '0 0 0 0'
    }), {
      region: 'south',
      contentEl: 'south',
      height: 40,
      minSize: 40,
      maxSize: 40,
      margins: '0 0 0 0',
      frame: true,
      baseCls: 'x-plain'
    }, {
      region: 'west',
      stateId: 'navigation-panel',
      id: 'west-panel',
      title: '导航',
      split: true,
      width: 200,
      minWidth: 200,
      maxWidth: 200,
      collapsible: true,
      animCollapse: true,
      margins: '0 0 0 8',
      layout: 'accordion',
      items: [{
        title: '功能',
        iconCls: 'icon-nav',
        layout: 'fit',
        items: Ext.create(namespace + '.NavTree')
      }, {
        title: '设置',
        iconCls: 'icon-setting',
        html: '<p>设置设置设置设置设置设置设置设置</p>'
      }, {
        title: '信息',
        iconCls: 'icon-info',
        html: '<p>信息信息信息信息信息信息信息信息</p>'
      }]
    }, Ext.create('Ext.tab.Panel', {
      id: 'mainTabs',
      region: 'center',
      margins: '0 8 0 0',
      enableTabScroll: true,
      defaults: { autoScroll: true },
      plugins: Ext.create(namespace + '.TabCloseMenu', {
        closeTabText: '关闭标签',
        closeOthersTabsText: '关闭其它标签',
        closeAllTabsText: '关闭全部'
      }),
      activeTab: 0,
      items: [{
        title: '主页',
        closable: false,
        autoScroll: true,
        iconCls: 'icon-home',
        contentEl: 'center1'
      }]
    })]
  });
});