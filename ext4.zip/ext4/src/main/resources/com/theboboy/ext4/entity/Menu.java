package com.theboboy.ext4.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "t_menu")
public class Menu implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GenericGenerator(name = "base64UuidGenerator", strategy = "com.theboboy.ext4.util.Base64UuidGenerator")
	@GeneratedValue(generator = "base64UuidGenerator")
	@Column(name = "id", length = 22)
	private String id;

	@Column(name = "name", nullable = false)
	private String name;

	@Column(name="code", nullable=false)
	private int code;

	@Column(name="hexstr", nullable=false)
	private String hexstr;

	@Column(name="pid")
	private String pid;

	@Column(name="path")
	private String path;
	
	@Column(name="icon")
	private String icon;

	public Menu() {
		super();
	}
	
	public Menu(String id, String name, int code, String hexstr, String pid) {
		super();
		this.id = id;
		this.name = name;
		this.code = code;
		this.hexstr = hexstr;
		this.pid = pid;
	}

	public Menu(String id, String name, int code, String hexstr, String pid, String icon, String path) {
		super();
		this.id = id;
		this.name = name;
		this.code = code;
		this.hexstr = hexstr;
		this.pid = pid;
		this.icon = icon;
		this.path = path;
	}

	
	/////////////////////////////////////////////////////
	//               Getters and Setters               //
	/////////////////////////////////////////////////////
	//<--15 spaces-->                   <--15 spaces-->//
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getHexstr() {
		return hexstr;
	}

	public void setHexstr(String hexstr) {
		this.hexstr = hexstr;
	}

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

}
