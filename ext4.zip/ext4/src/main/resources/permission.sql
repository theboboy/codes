/*
SQLyog Ultimate v10.51 
MySQL - 5.5.33 : Database - db_permission
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_permission` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `db_permission`;

/*Table structure for table `t_button` */

DROP TABLE IF EXISTS `t_button`;

CREATE TABLE `t_button` (
  `id` char(22) NOT NULL COMMENT 'ID',
  `name` varchar(20) NOT NULL COMMENT '按钮名称',
  `title` varchar(20) NOT NULL COMMENT '按钮文字',
  `mid` char(22) DEFAULT NULL COMMENT '菜单ID',
  PRIMARY KEY (`id`),
  KEY `mid` (`mid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_button` */

/*Table structure for table `t_menu` */

DROP TABLE IF EXISTS `t_menu`;

CREATE TABLE `t_menu` (
  `id` char(22) NOT NULL COMMENT 'ID',
  `name` varchar(50) NOT NULL COMMENT '菜单名称',
  `code` int(11) NOT NULL COMMENT '编码',
  `hexstr` varchar(64) NOT NULL COMMENT '编码的十六进制',
  `pid` char(22) DEFAULT NULL COMMENT '父ID',
  `icon` varchar(255) DEFAULT NULL COMMENT '图标',
  `path` varchar(255) DEFAULT NULL COMMENT '路径',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  CONSTRAINT `t_menu_ibfk_1` FOREIGN KEY (`pid`) REFERENCES `t_menu` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_menu` */

insert  into `t_menu`(`id`,`name`,`code`,`hexstr`,`pid`,`icon`,`path`) values ('a9xhXyLUTn6tJ0c8gjNI1A','子菜单3',266,'010A','io6Gm3qvS0m7MrbEdz21xw',NULL,NULL),('bIwx_-L7SE2Rik4GQlMczA','子菜单2',258,'0102','io6Gm3qvS0m7MrbEdz21xw',NULL,NULL),('hiEbY86BQg2xEnjSrYOl7A','菜单2',2,'02',NULL,NULL,NULL),('io6Gm3qvS0m7MrbEdz21xw','菜单1',1,'01',NULL,NULL,NULL),('JvV0IFvoQxyBxxMeiM-Dfg','子菜单1',257,'0101','io6Gm3qvS0m7MrbEdz21xw',NULL,NULL),('kd-dOabHTJ2QxqIqNz5Dbw','子菜单4',267,'010B','io6Gm3qvS0m7MrbEdz21xw',NULL,NULL),('VmbuydEAR8KFP5KOsjcTug','子菜单5',513,'0201','hiEbY86BQg2xEnjSrYOl7A',NULL,NULL);

/*Table structure for table `t_role` */

DROP TABLE IF EXISTS `t_role`;

CREATE TABLE `t_role` (
  `id` char(22) NOT NULL COMMENT 'ID',
  `name` varchar(50) NOT NULL COMMENT '角色名称',
  `info` varchar(100) DEFAULT NULL COMMENT '说明',
  `is_system` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否是系统角色',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_role` */

/*Table structure for table `t_user` */

DROP TABLE IF EXISTS `t_user`;

CREATE TABLE `t_user` (
  `id` char(22) NOT NULL COMMENT 'ID',
  `username` varchar(20) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT 'MD5加密的密码',
  `nickname` varchar(20) NOT NULL COMMENT '昵称',
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `nickname` (`nickname`),
  KEY `username_2` (`username`,`password`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_user` */

/*Table structure for table `t_user_role` */

DROP TABLE IF EXISTS `t_user_role`;

CREATE TABLE `t_user_role` (
  `id` char(22) NOT NULL COMMENT 'ID',
  `uid` char(22) NOT NULL COMMENT '用户ID',
  `rid` char(22) NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `rid` (`rid`),
  CONSTRAINT `t_user_role_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `t_user` (`id`),
  CONSTRAINT `t_user_role_ibfk_2` FOREIGN KEY (`rid`) REFERENCES `t_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_user_role` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
