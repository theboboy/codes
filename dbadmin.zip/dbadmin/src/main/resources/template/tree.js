var ${db_name_upper}Vars = {};

${db_name_upper}Vars.baseURL = '${base_url}&method=';

${db_name_upper}Tree = Ext.extend(Ext.tree.TreePanel, {
  constructor: function () {
  ${db_name_upper}Tree.superclass.constructor.call(this, {
      //title: '${db}',
      autoScroll: true,
      //autoHeight: true,
      border: false,
      useArrows: true,
      rootVisible: true,
      root: {
        nodeType: 'async',
        id: '${db_name_lower}Root',
        text: '${db}',
        expanded: true,
        uiProvider: false
      },
      rootVisible: false,
      loader: new Ext.tree.TreeLoader({
        dataUrl: ${db_name_upper}Vars.baseURL + 'list'
      }),
      listeners: {
        afterrender: function(cmp) {
          //cmp.expandAll();
        },
        dblclick: function(node, e) {
          if(node.leaf) {
            //Ext.Msg.alert('提示', '表名：' + node.id);
            
            var dbName = node.parentNode.text;
            
            var tabs = Ext.getCmp('centerTabs');
            
            if(!tabs) {
              return;
            }
            
            var tabId = 'center_tab_' + node.id;
            
            if (Ext.getCmp(tabId)) {
              tabs.setActiveTab(tabId);
              return;
            }
            
            Ext.Msg.wait('正在接收数据，请耐心等待...', '系统提示');
            
            ($).getJs('grid?db=' + dbName + '&table=' + node.id, function() {
              var arr = node.id.split('_');
                
              var name = '';
                
              for(var i = 0, len = arr.length; i < len; i++) {
                name += arr[i].charAt(0).toUpperCase() + arr[i].substr(1);
              }
                
              var grid = null;
                
              eval('grid = new ' + name + 'GridPanel();');
              
              grid.closable = true;
                
              var tab = new Ext.Panel({
                id: tabId,
                title: node.text,
                closable: true,
                layout: 'fit',
                items: [grid]
              });
              
              tabs.add(tab).show();
              
              Ext.Msg.hide();
            }, false);
          }
        }
      }
  });
  }
});

