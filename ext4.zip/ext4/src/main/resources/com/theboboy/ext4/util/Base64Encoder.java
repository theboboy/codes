package com.theboboy.ext4.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;

/**
 * 将byte[]转换成Base64的字符串
 * 
 * 写这个类的原因：
 * 1.因为JDK提供的BASE64Encoder是sun.misc，在某些情况下非公开，需要手动设置
 * 2.JDK中提供的BASE64Encoder中含有'+'和'/'，这两个符号在URL传输下会引起混淆
 *   这里用'-'替换'+'，用'_'替换'/'
 * 
 * 使用方法：
 *     String str = ""; // 要加密的字符串
 *     String algorithm = "MD5"; // 可以是MD5(24位)|MD2(24位)|SHA-1(28位)|SHA-256(44位)|SHA-384(64位)|SHA-512(90位)
 *     byte[] bytes = MessageDigest.getInstance(algorithm).digest(str.getBytes()); // 用信息摘要算法算出byte[]
 *     String md5 = new Base64Encoder().encode(bytes); // 将byte[]转换成Base64的字符串
 * 
 * @author theboboy
 * 
 * @version 1.0
 */
public final class Base64Encoder {

	private static final char[] pemArray = { 'A', 'B', 'C', 'D', 'E', 'F',
			'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S',
			'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
			'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's',
			't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5',
			'6', '7', '8', '9', '-', '_' };

	private PrintStream pStream;

	private int bytesPerAtom() {
		return 3;
	}

	private int bytesPerLine() {
		return 57;
	}

	private void encodeBufferPrefix(OutputStream paramOutputStream)
			throws IOException {
		this.pStream = new PrintStream(paramOutputStream);
	}

	private void encodeBufferSuffix(OutputStream paramOutputStream)
			throws IOException {
	}

	private void encodeLinePrefix(OutputStream paramOutputStream, int paramInt)
			throws IOException {
	}

	private void encodeLineSuffix(OutputStream paramOutputStream)
			throws IOException {
		this.pStream.println();
	}

	public String encode(byte[] paramArrayOfByte) {
		ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
		ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(
				paramArrayOfByte);
		String str = null;
		try {
			encode(localByteArrayInputStream, localByteArrayOutputStream);

			str = localByteArrayOutputStream.toString("8859_1");
		} catch (Exception localException) {
			throw new Error("CharacterEncoder.encode internal error");
		}
		return str;
	}

	private void encode(InputStream paramInputStream,
			OutputStream paramOutputStream) throws IOException {
		byte[] arrayOfByte = new byte[bytesPerLine()];

		encodeBufferPrefix(paramOutputStream);
		while (true) {
			int j = readFully(paramInputStream, arrayOfByte);
			if (j == 0) {
				break;
			}
			encodeLinePrefix(paramOutputStream, j);
			for (int i = 0; i < j; i += bytesPerAtom()) {
				if (i + bytesPerAtom() <= j)
					encodeAtom(paramOutputStream, arrayOfByte, i,
							bytesPerAtom());
				else {
					encodeAtom(paramOutputStream, arrayOfByte, i, j - i);
				}
			}
			if (j < bytesPerLine()) {
				break;
			}
			encodeLineSuffix(paramOutputStream);
		}

		encodeBufferSuffix(paramOutputStream);
	}

	private int readFully(InputStream paramInputStream, byte[] paramArrayOfByte)
			throws IOException {
		for (int i = 0; i < paramArrayOfByte.length; ++i) {
			int j = paramInputStream.read();
			if (j == -1)
				return i;
			paramArrayOfByte[i] = (byte) j;
		}
		return paramArrayOfByte.length;
	}

	private void encodeAtom(OutputStream paramOutputStream,
			byte[] paramArrayOfByte, int paramInt1, int paramInt2)
			throws IOException {
		int i;
		int j;
		int k;
		if (paramInt2 == 1) {
			i = paramArrayOfByte[paramInt1];
			j = 0;
			k = 0;
			paramOutputStream.write(pemArray[(i >>> 2 & 0x3F)]);
			paramOutputStream
					.write(pemArray[((i << 4 & 0x30) + (j >>> 4 & 0xF))]);
			paramOutputStream.write(61);
			paramOutputStream.write(61);
		} else if (paramInt2 == 2) {
			i = paramArrayOfByte[paramInt1];
			j = paramArrayOfByte[(paramInt1 + 1)];
			k = 0;
			paramOutputStream.write(pemArray[(i >>> 2 & 0x3F)]);
			paramOutputStream
					.write(pemArray[((i << 4 & 0x30) + (j >>> 4 & 0xF))]);
			paramOutputStream
					.write(pemArray[((j << 2 & 0x3C) + (k >>> 6 & 0x3))]);
			paramOutputStream.write(61);
		} else {
			i = paramArrayOfByte[paramInt1];
			j = paramArrayOfByte[(paramInt1 + 1)];
			k = paramArrayOfByte[(paramInt1 + 2)];
			paramOutputStream.write(pemArray[(i >>> 2 & 0x3F)]);
			paramOutputStream
					.write(pemArray[((i << 4 & 0x30) + (j >>> 4 & 0xF))]);
			paramOutputStream
					.write(pemArray[((j << 2 & 0x3C) + (k >>> 6 & 0x3))]);
			paramOutputStream.write(pemArray[(k & 0x3F)]);
		}
	}

}
