package com.theboboy.tools.dbadmin.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.util.HtmlUtils;

import com.theboboy.tools.dbadmin.dialect.Dialect;
import com.theboboy.tools.dbadmin.util.Json;
import com.theboboy.tools.dbadmin.util.NameUtils;
import com.theboboy.tools.dbadmin.util.PropertyMgr;

@SuppressWarnings({ "rawtypes" })
public class StmtServlet extends HttpServlet {

	private static final long serialVersionUID = 8767989100087031294L;

	protected static String URL = null;

	private Dialect dialect;
	
	private String encoding;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		config.getServletContext().setAttribute("DbName", NameUtils.hungaryToCamelCase("dbnames", true));
		
		String dialectName = config.getInitParameter("dialect");
		
		if(dialectName == null || dialectName.length() == 0) {
			dialectName = config.getServletContext().getInitParameter("dialect");
			if(dialectName == null || dialectName.length() == 0) {
				throw new ServletException("dialect is null or empty");
			}
		}
		
		try {
			Class c = Class.forName(dialectName);
			dialect = (Dialect) c.newInstance();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		
		this.encoding = config.getInitParameter("encoding");
		
		if(encoding == null || encoding.length() == 0) {
			encoding = config.getServletContext().getInitParameter("encoding");
			if(encoding == null || encoding.length() == 0) {
				encoding = "UTF-8";
			}
		}
		
	}
	
	@Override
	public void destroy() {
		super.destroy();
	}
	
	private Connection getConnection(String db) {
		try {
			return dialect.newConnection(PropertyMgr.getUrl(db), PropertyMgr.getUser(db), PropertyMgr.getPwd(db));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding(encoding);
		response.setCharacterEncoding(encoding);
		
		Result result = new Result();
		
		String db = request.getParameter("db");
		
		String sql = request.getParameter("stmt");
		
		System.out.println(sql);
		
		// return column names and list
		
		sql = sql.trim();
		
		try {
			
			Connection conn = getConnection(db);
			
			Statement stmt = conn.createStatement();
			
			if(sql.startsWith("select ") || sql.startsWith("show ") || sql.startsWith("explain ")
					|| sql.startsWith("SELECT ") || sql.startsWith("SHOW ") || sql.startsWith("EXPLAIN ")) {
				
				long l1 = System.currentTimeMillis();
				
				ResultSet rs = stmt.executeQuery(sql);
				
				long l2 = System.currentTimeMillis();
				
				ResultSetMetaData rsmd = rs.getMetaData();
				
				int columnCount = rsmd.getColumnCount();
				
				String[] columnNames = new String[columnCount];
				
				for(int i = 1; i <= columnCount; i ++) {
					columnNames[i - 1] = rsmd.getColumnLabel(i);
				}
				
				ArrayList<HashMap<String, Object>> rows = new ArrayList<HashMap<String, Object>>(columnCount);
				
				while(rs.next()) {
					
					HashMap<String, Object> cols = new HashMap<String, Object>();
					
					for(int i = 1; i <= columnCount; i++) {
						
						Object value = rs.getObject(i);
						
						if(value instanceof String) {
							value = HtmlUtils.htmlEscape((String) value);
							value = filterUnicodeString((String) value);
						}
						
						cols.put(columnNames[i - 1], value);
						
					}
					
					rows.add(cols);
					
				}
				
				long l3 = System.currentTimeMillis();
				
				result.props.put("columns", columnNames);
				
				result.props.put("data", rows);
				
				result.props.put("info", "查询耗时：" + (l2 -l1) + "毫秒，总耗时：" + (l3 - l1) + "毫秒");
				
				result.success = true;
				
			} else {
				
				conn.setAutoCommit(false);
				
				int rows = stmt.executeUpdate(sql);
				
				conn.commit();
				
				result.props.put("dbMsg", "执行成功，影响行数：" + rows);
				
				result.success = true;
				
			}
			
			stmt.close();
			
			conn.close();
			
		} catch (SQLException e) {
			
			StackTraceElement[] es = e.getStackTrace();
			
			String[] arr = new String[es.length + 2];
			
			arr[0] = e.getMessage();
			
			arr[1] = "<hr />";
			
			for(int i = 0, len = es.length; i < len; i++) {
				arr[i + 2] = es[i].toString();
			}
			
			result.success = true;
			
			result.props.put("exMsg", arr);
			
		}
		
		outputJson(response, result);
		
	}
	
	public class Result {
		public boolean success;
		public String msg;
		public HashMap<String, Object> props = new HashMap<String, Object>();
	}
	
	private void outputJson(HttpServletResponse response, Result result) {
		if(!result.success) {
			response.setStatus(600);
		}
		response.setContentType("text/plain");
		try {
			PrintWriter out = response.getWriter();
			String json = Json.toJsonString(result);
			//String json = JSON.toJSONString(result);
			//json = json.replaceAll("<", "&lt").replaceAll(">", "&gt;");
			out.print(json);
			out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static String filterUnicodeString(String value) {
		if (value == null) {
			return null;
		}
		char[] xmlChar = value.toCharArray();
		for (int i = 0; i < xmlChar.length; i++) {
			if (xmlChar[i] > 0xFFFD) {
				xmlChar[i] = ' ';// 用空格替换
			} else if (xmlChar[i] < 0x20 && xmlChar[i] != 't'
					& xmlChar[i] != 'n' & xmlChar[i] != 'r') {
				xmlChar[i] = ' ';// 用空格替换
			}
		}
		return new String(xmlChar);
	}

}
