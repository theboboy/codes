package com.theboboy.ext4.test;

import java.io.File;
import java.util.ArrayList;

import org.junit.Test;

import com.alibaba.druid.support.json.JSONUtils;
import com.theboboy.ext4.entity.Menu;
import com.theboboy.ext4.po.Tree;
import com.theboboy.ext4.util.UuidUtils;

public class Tests {

	@Test
	public void modifyIcons() {
		
		File folder = new File("D:\\icon\\");
		
		File[] icons = folder.listFiles();
		
		File dist = new File(folder, "dist");
		
		for(int i = 0, len = icons.length; i < len; i++) {
			
			String newName = icons[i].getName().replaceAll("_24x24", "");
			
			icons[i].renameTo(new File(dist, newName));
		}
		
	}

	@Test
	public void generateCompressedUUIDs() {
		
		for(int i = 0; i < 10; i++) {
			System.out.println(UuidUtils.compressRandom());
		}
		
	}

}
